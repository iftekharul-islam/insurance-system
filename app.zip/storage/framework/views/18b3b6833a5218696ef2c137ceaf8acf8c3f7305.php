
<?php $__env->startSection('title', 'Edit Notice'); ?>
<?php $__env->startSection('content'); ?>

    <main class="app-content">
        <h3>Notice Edit</h3>
        <hr />
        <div class="row">

            <div class="col-md-12">
                <div class="tile">
                    <!---Success Message--->

                    <!---Error Message--->


                    <div class="tile-body">
                        <form method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group col-md-12">
                                <label class="control-label">Add Notice</label>
                                <input class="form-control" name="notice" value="<?php echo e($data->notice); ?>" id="category"
                                    type="text" placeholder="Update Notice">
                                <?php if($errors->has('notice')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('notice')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-12">
                                <label class="control-label">Notice Description</label>
                                <textarea class="form-control" name="notice_dec" id="" cols="30" rows="5"><?php echo e($data->notice_dec); ?></textarea>
                                <?php if($errors->has('notice_dec')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('notice_dec')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-12">
                                <label class="control-label">Notice Type</label>
                                <select class="form-control" name="notice_type">
                                    <option value="0">New</option>
                                    <option value="1">Important</option>
                                </select>
                                <?php if($errors->has('notice_type')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('notice_type')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-4 align-self-end">

                                <button class="btn" type="submit" style="background:#009688;color:#fff;">Update&nbsp;<i
                                        class="fa-solid fa-pencil"></i></button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>

    </main>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/geekscua/bfss-ltd.com/resources/views/admin/notice-edit.blade.php ENDPATH**/ ?>