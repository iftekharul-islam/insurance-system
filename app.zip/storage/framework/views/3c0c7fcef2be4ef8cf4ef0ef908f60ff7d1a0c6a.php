<?php $__env->startSection('title', 'Edit Admin'); ?>
<?php $__env->startSection('content'); ?>



    <main class="app-content">
        <h3>Add Admin</h3>
        <hr />
        <div class="row">

            <div class="col-md-12">
                <div class="tile">
                    <!---Success Message--->

                    <!---Error Message--->


                    <div class="tile-body">
                        <form method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group col-md-12">
                                <label class="control-label">Name</label>
                                <input class="form-control" value="<?php echo e($data->name); ?>" name="name" id="category"
                                    type="text" placeholder="Name">
                                <?php if($errors->has('name')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12">
                                <label class="control-label">User Name</label>
                                <input class="form-control" value="<?php echo e($data->email); ?>" name="email" id="category"
                                    type="text" placeholder="Emil">
                                <?php if($errors->has('email')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </div>

                            <style>
                                .toggle-password {
                                    float: right;
                                    cursor: pointer;
                                    margin-right: 10px;
                                    margin-top: -25px;
                                }
                            </style>

                            <div class="form-group col-md-12">
                                <label class="control-label">Password</label>
                                <input type="password" name="password" id="password" class="form-control" value="">
                                <i class="toggle-password fa fa-fw fa-eye-slash"></i>

                                <?php if($errors->has('password')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('password')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12">
                                <label class="control-label">Phone Number</label>
                                <input type="text" name="phone" id="phone"  value="<?php echo e($data->phone); ?>" class="form-control">

                                <?php if($errors->has('password')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('phone')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12">
                                <label class="control-label">Role</label>
                                <select name="is_admin" class="form-control">
                                    <?php if($data->is_admin == 1): ?>
                                        <option value="1">Super Admin</option>
                                    <?php elseif($data->is_admin == 2): ?>
                                        <option value="2">Loan Manager</option>
                                    <?php elseif($data->is_admin == 3): ?>
                                        <option value="3">Loan Officer</option>
                                    <?php elseif($data->is_admin == 4): ?>
                                        <option value="4">Notice Admin</option>
                                    <?php endif; ?>
                                    <option value="2">Loan Manager</option>
                                    <option value="3">Loan Officer</option>
                                    <option value="4">Notice Admin</option>

                                </select>
                                <?php if($errors->has('is_admin')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('is_admin')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-4 align-self-end">

                                <input type="submit" name="submit" id="submit" class="btn btn-primary" value=" Update">
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>

    </main>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(".toggle-password").click(function() {
            $(this).toggleClass("fa-eye fa-eye-slash");
            input = $(this).parent().find("input");
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } else {
                input.attr("type", "password");
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/geekscua/bfss-ltd.com/resources/views/admin/stoff-profile/admin-edit.blade.php ENDPATH**/ ?>