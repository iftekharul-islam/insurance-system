<?php $__env->startSection('title', 'Loan Submit'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        @media  only screen and (max-width: 600px) {
            .tile {
                overflow-x: scroll;
            }
        }
    </style>

    <main class="app-content">

        <hr />
        <div class="row">
            <div class="col-md-12">
                <div class="tile" style="border-top: 3px solid #009688;border-radius: 13px 13px 0px 0px;">
                    <div class="tile-body">
                        <h1>Amount Received Form</h1>
                        <form action="<?php echo e(route('loan.editform')); ?>" method="POST">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th>Enter User ID</th>

                                </tr>
                            </thead>

                            <tbody>

                                    <?php echo csrf_field(); ?>

                                    <tr>

                                        <td>
                                            <div class="form-group">
                                                <input id="" type="text" class="form-control"
                                                    name="id" placeholder="Enter User id">
                                            </div>
                                        </td>

                                    </tr>


                            </tbody>


                        </table>
                        <button type="submit">Submit</button>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Clients'Project\LoanProject\Version-2Copy\resources\views/accountsetup/reopen/old_form.blade.php ENDPATH**/ ?>