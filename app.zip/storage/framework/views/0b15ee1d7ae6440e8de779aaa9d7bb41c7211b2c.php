<?php $__env->startSection('title', 'Notice'); ?>
<?php $__env->startSection('content'); ?>

    <main class="app-content">


        <h3>All Notice</h3>
        <hr />

        <div class="card">
            <div class="card-header">
                Notice
            </div>
            <div class="card-body">

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <blockquote class="blockquote mb-3">
                        <footer class="blockquote-footer">
                            <cite title="Source Title" class="text-info">
                                <i class="fa-solid fa-calendar-days"></i>
                                Published Date : <span><?php echo e(\Carbon\Carbon::parse($data->created_at)->format('d-M-Y')); ?></span>
                            </cite>
                            <cite title="Source Title"></cite>
                        </footer>
                        <cite title="" style="text-align: center">
                            <h5><?php echo e($data->notice); ?></h5>
                        </cite>
                        <p class="mt-2">
                            <?php echo e($data->notice_dec); ?>

                        </p>

                        <footer class="blockquote-footer">
                            <cite title="Source Title" class="text-info">File Name: <span
                                    class="text-black">notic-file.pdf</span></cite>
                            <cite title="Source Title">
                                <?php if(!empty($data->notice_pdf)): ?>
                                    <a href="<?php echo e(asset('uploads/pdf/') . '/' . $data->notice_pdf); ?>" download="" class="btn btn-primary btn-sm">Download</a>
                                <?php endif; ?>
                            </cite>
                        </footer>
                    </blockquote>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>





    </main>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Upwork\Loan\app\resources\views/home.blade.php ENDPATH**/ ?>