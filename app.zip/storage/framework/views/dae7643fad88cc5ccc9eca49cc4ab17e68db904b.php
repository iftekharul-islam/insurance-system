<?php $__env->startSection('title', 'Member Profile'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        @media  only screen and (max-width: 600px) {
            .tile {
                overflow-x: scroll;
            }
        }

        .tile {
            border-top: 3px solid #009688;
            border-radius: 13px 13px 0px 0px;
        }

        h4 {
            background: #ffe1e1;
            padding: 4px;
            font-size: 17px;
        }
    </style>
    <main class="app-content">


        <div class="row">
            <div class="col-md-12">
                <div class="tile">


                    <?php if($data->rejected_reason): ?>
                        <!---Success Message--->
                        <div class="alert alert-danger">
                            <li><?php echo e($data->rejected_reason); ?></li>
                        </div>
                        <!---Error Message--->
                    <?php endif; ?>


                    <div class="tile-body">
                        <h4>Loan Customer Information :</h4>
                        <table class="table table-hover table-bordered">

                            <thead>
                                <tr>
                                    <th>Name of loan customer</th>
                                    <th><?php echo e($data->name); ?></th>
                                    <th>Customer photo</th>
                                    <td>
                                        <img src="<?php echo e(asset('uploads/loan_profile/') . '/' . $data->loan_owner_image); ?>"
                                            style="width: 67px;">
                                    </td>
                                </tr>
                                <tr>
                                    <th>Phone Number </th>
                                    <td><?php echo e($data->mobile); ?></td>
                                </tr>
                                <tr>
                                    <th>ID Card Number </th>
                                    <th><?php echo e($data->loan_owner_card_no); ?></th>
                                    <th>ID Card Photo</th>
                                    <td>
                                        <img src="<?php echo e(asset('uploads/loan_profile/') . '/' . $data->loan_owner_id_card); ?>"
                                            style="    width: 70px;height: 60px;">
                                        <img src="<?php echo e(asset('uploads/loan_profile/') . '/' . $data->loan_owner_id_bk_img); ?>"
                                            style="    width: 70px;height: 60px;">

                                    </td>
                                </tr>
                                <tr>
                                    <th>Father's name</th>
                                    <td><?php echo e($data->fathers_name); ?></td>
                                    <th>Mother's name</th>
                                    <td><?php echo e($data->mothers_name); ?></td>
                                </tr>

                                <tr>

                                    <th>Date of Birth</th>
                                    <td><?php echo e($data->day); ?>-Day</td>
                                    <td><?php echo e($data->month); ?>-Month</td>
                                    <td><?php echo e($data->year); ?>-Year</td>
                                </tr>

                                <tr>

                                    <?php
                                        $zela = preg_replace('/\d/', '', $data->loan_owner_zila);
                                    ?>

                                    <?php
                                        $upazela = preg_replace('/\d/', '', $data->loan_owner_upazila);
                                    ?>

                                    <?php
                                        $union = preg_replace('/\d/', '', $data->loan_owner_union);
                                    ?>


                                    <th>Permanent Address</th>
                                    <td>District&nbsp;<?php echo e($zela); ?></td>
                                    <td>Thana / Upazila&nbsp;<?php echo e($upazela); ?></td>
                                    <td>Union&nbsp;<?php echo e($union); ?></td>
                                </tr>


                                <tr>

                                    <th>Post office</th>
                                    <td><?php echo e($data->loan_owner_pincode); ?></td>
                                    <th>Village </th>
                                    <td><?php echo e($data->loan_owner_gram); ?></td>

                                </tr>

                                <tr>

                                    <th>Branch </th>
                                    <td><?php echo e($data->loan_owner_branch); ?></td>
                                    <th>Loan Ammount </th>
                                    <td style="font-weight: 800;"><?php echo e($data->loan_amount); ?> ৳</td>

                                </tr>



                            </thead>


                        </table>


                        <h4>Granter's Information No. 1 :</h4>
                        <table class="table table-hover table-bordered">


                            <tr>
                                <th>Granter Name</th>
                                <th><?php echo e($data->granter_name); ?></th>
                                <th>Granter Photo</th>
                                <td>
                                    <img src="<?php echo e(asset('uploads/loan_profile/') . '/' . $data->granter_image); ?>"
                                        style="width: 79px;
    height: 79px;">
                                </td>
                            </tr>
                            <tr>
                                <th>Granter Phone Number</th>
                                <td><?php echo e($data->granter_mobile); ?></td>
                                <th>ID Card Number </th>
                                <th><?php echo e($data->granter_id_card_no); ?></th>

                            </tr>
                            <tr>
                                <th>Father's name</th>
                                <td><?php echo e($data->granter_fathers_name); ?></td>
                                <th>Mother's name</th>
                                <td><?php echo e($data->granter_mothers_name); ?></td>
                            </tr>

                            <tr>

                                <th>Date of Birth</th>
                                <td><?php echo e($data->granter_day); ?>-Day</td>
                                <td><?php echo e($data->granter_month); ?>-Month</td>
                                <td><?php echo e($data->granter_year); ?>-Year</td>
                            </tr>

                            <tr>

                                <?php
                                    $granterzela = preg_replace('/\d/', '', $data->granter_zila);
                                ?>

                                <?php
                                    $granterupazela = preg_replace('/\d/', '', $data->granter_upazila);
                                ?>

                                <?php
                                    $granterunion = preg_replace('/\d/', '', $data->granter_union);
                                ?>

                                <th>Permanent Address</th>
                                <td>District&nbsp;<?php echo e($granterzela); ?></td>
                                <td>Thana / Upazila&nbsp;<?php echo e($granterupazela); ?></td>
                                <td>Union&nbsp;<?php echo e($granterunion); ?></td>
                            </tr>


                            <tr>

                                <th>Post office</th>
                                <td><?php echo e($data->granter_pincode); ?></td>
                                <th>Village </th>
                                <td><?php echo e($data->granter_gram); ?></td>

                            </tr>




                        </table>

                        <!-------------------------Granter 2 information------------------->
                        <h4>Granter's Information No. 2 :</h4>
                        <table class="table table-hover table-bordered">


                            <tr>
                                <th>Granter Name</th>
                                <td><?php echo e($data->granter_2_name); ?></td>
                                <th>Granter Photo</th>
                                <td>
                                    <img src="<?php echo e(asset('uploads/loan_profile/') . '/' . $data->granter__2_image); ?>"
                                        style="width: 79px;
    height: 79px;;">
                                </td>
                            </tr>
                            <tr>
                                <th>Granter Phone Number</th>
                                <td><?php echo e($data->granter_2_id_card_no); ?></td>
                                <th>ID Card Number </th>
                                <th><?php echo e($data->granter_id_card_no); ?></th>

                            </tr>
                            <tr>
                                <th>Father's name</th>
                                <td><?php echo e($data->granter_2_fathers_name); ?></td>
                                <th>Mother's name</th>
                                <td><?php echo e($data->granter_mothers_name); ?></td>
                            </tr>

                            <tr>

                                <th>Date of Birth</th>
                                <td><?php echo e($data->granter_2_day); ?>-Day</td>
                                <td><?php echo e($data->granter_2_month); ?>-Month</td>
                                <td><?php echo e($data->granter_2_year); ?>-Year</td>
                            </tr>

                            <tr>
                                <?php
                                    $granterzela2 = preg_replace('/\d/', '', $data->granter_2_zila);
                                ?>
                                <?php
                                    $granterupazela2 = preg_replace('/\d/', '', $data->granter_2_upazila);
                                ?>
                                <?php
                                    $granterunion2 = preg_replace('/\d/', '', $data->granter_2_union);
                                ?>
                                <th>Permanent Address</th>
                                <td>District&nbsp;<?php echo e($granterzela2); ?></td>
                                <td>Thana / Upazila&nbsp;<?php echo e($granterupazela2); ?></td>
                                <td>Union&nbsp;<?php echo e($granterunion2); ?></td>
                            </tr>
                            <tr>
                                <th>Post office</th>
                                <td><?php echo e($data->granter_2_pincode); ?></td>
                                <th>Village </th>
                                <td><?php echo e($data->granter_2_gram); ?></td>
                            </tr>
                        </table>

                    </div>
                </div>
            </div>
        </div>

    </main>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Upwork\Loan\app\resources\views/n-view-form.blade.php ENDPATH**/ ?>