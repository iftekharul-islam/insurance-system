<?php $__env->startSection('title', 'List Member'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        @media  only screen and (max-width: 600px) {
            .tile {
                overflow-x: scroll;
            }
        }
    </style>

    <main class="app-content">

        <div class="row">
            <div class="col-md-12">
                <div class="d-flex justify-content-between">
                    <div class=""> <h3>Member List</h3></div>

                </div>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="col-md-12">
                <div class="tile" style="    border-top: 3px solid #009688;border-radius: 13px 13px 0px 0px;">
                    <div class="tile-body">
                        <table class="table table-hover table-bordered" id="sampleTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    
                                    <th>Loan Officer Name</th>
                                    <th>Loaner Name</th>
                                    <th>Total Amout</th>
                                    <th>Print</th>
                                    <th>Return Amount</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $user_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($data['id']); ?></td>

                                        <td><?php echo e($data['loan_office']); ?></td>

                                        <td>
                                           <?php echo e($data['loaner_name']); ?>

                                        </td>
                                        <td>
                                           <?php echo e($data['total_amount']); ?>

                                        </td>

                                        <td>
                                            <a href="<?php echo e(route('print.single.user', $data['id'])); ?>"
                                                onclick="return confirm('Are you Sure?')">
                                                <button class="btn btn-secondary"
                                                    type="button">Print&nbsp;<i class="fa-solid fa-print"></i>
                                                </button>
                                        </td>
                                        <td>
                                            <?php echo e($data['wapisloan']); ?>

                                         </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery.print/1.6.2/jQuery.print.js"
        integrity="sha512-BaXrDZSVGt+DvByw0xuYdsGJgzhIXNgES0E9B+Pgfe13XlZQvmiCkQ9GXpjVeLWEGLxqHzhPjNSBs4osiuNZyg=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $(document).ready(function() {
            $('#btn-print').printPage();
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Desktop\llllllll\app (1)\resources\views/manager/loanofficereport.blade.php ENDPATH**/ ?>