<?php $__env->startSection('title', 'List Member'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        @media  only screen and (max-width: 600px) {
            .tile {
                overflow-x: scroll;
            }
        }
    </style>

    <main class="app-content">

        <div class="row">
            <div class="col-md-12">
                <div class="tile" style="border-top: 3px solid #009688;border-radius: 13px 13px 0px 0px;">
                    <div class="tile-body">



                        <h1>Member List</h1>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group" style="line-height: 34px;margin-top: 10px;">
                                    <div class="row">
                                        <div class="col-3">
                                            <label class="control-label" style="font-weight:bold;">
                                                Search By Type
                                                :&nbsp;<sup style="color:red">*</sup>
                                            </label>

                                        </div>
                                        <div class="col-8">
                                           <form action="<?php echo e(route('manager.member.list.bystatus')); ?>" method="POST" id="statusType">
                                            <?php echo csrf_field(); ?>
                                            <select required="" class="form-control" name="loanstats" id="SearchType">
                                                <option value="">
                                                    <?php if(!empty($selected_type)): ?>
                                                        <?php if($selected_type == '0'): ?>
                                                            Pending
                                                        <?php elseif($selected_type == '1'): ?>
                                                            Approved
                                                        <?php else: ?>
                                                            --Select Type--
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        --Select Type--
                                                    <?php endif; ?>
                                                </option>
                                                <option value="0">Pending</option>
                                                <option value="1">Approved</option>
                                                <option value="4">Rejected</option>
                                            </select>
                                        </form>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <table class="table table-hover table-bordered" id="sampleTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>View</th>
                                    <th>Edit</th>
                                    <th>Print</th>
                                    <th>Status</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($data->form_id); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('uploads/loan_profile/') . '/' . $data->loan_owner_image); ?>"
                                                style="width: 78px;height: 78px;">
                                        </td>
                                        <td><?php echo e($data->name); ?></td>

                                        <td>
                                            <a href="<?php echo e(route('manager.loan.profile-view', $data->id)); ?>"
                                                class="btn btn-info">View&nbsp;
                                                <i class="fa-solid fa-eye"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <?php if($data->status == "0" && !$data->re_submit_status == '1'): ?>
                                                <a href="<?php echo e(route('manager.loanprofile.edit', $data->id)); ?>"
                                                    class="btn btn-primary">Edit&nbsp;<i class="fa-solid fa-pen"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('print.loanprofile', base64_encode($data->id))); ?>"
                                                onclick="return confirm('Are you Sure?')">
                                                <button class="btn btn-secondary"
                                                    type="button">Print&nbsp;<i class="fa-solid fa-print"></i>
                                                </button>
                                        </td>
                                        <td>


                                            <?php if($data->loan_close_reason == '1'): ?>
                                            <button class="btn btn-danger">Close</button>
                                            <?php else: ?>
                                            <?php if($data->re_submit_status == '1'): ?>

                                            <button class="btn btn-danger">Rejected</button>

                                            <?php else: ?>
                                                <?php if($data->status == 0): ?>
                                                    <button class="btn btn-danger">Pending</button>
                                                <?php elseif($data->status == "1" || $data->status == "2" || $data->status == "3"): ?>
                                                    <button class="btn btn-success">Approve&nbsp;
                                                        <i class="fa-solid fa-check"></i>
                                                    </button>
                                                <?php else: ?>

                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php endif; ?>



                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery.print/1.6.2/jQuery.print.js"
        integrity="sha512-BaXrDZSVGt+DvByw0xuYdsGJgzhIXNgES0E9B+Pgfe13XlZQvmiCkQ9GXpjVeLWEGLxqHzhPjNSBs4osiuNZyg=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $(document).ready(function() {
            $('#btn-print').printPage();
        });


        $('#SearchType').change(function() {
            document.getElementById('statusType').submit();

        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/geekscua/bfss-ltd.com/resources/views/manager/loan-member-list.blade.php ENDPATH**/ ?>