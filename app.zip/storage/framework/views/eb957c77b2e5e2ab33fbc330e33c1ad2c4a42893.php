<?php $__env->startSection('title', 'Officer Profile'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        @media  only screen and (max-width: 600px) {
            .tile {
                overflow-x: scroll;
            }
        }
    </style>

    <main class="app-content">

        <div class="row">
            <div class="col-md-12">
                <div class="tile" style="border-top: 3px solid #009688;border-radius: 13px 13px 0px 0px;">
                    <div class="tile-body">
                        <table class="table table-hover table-bordered" id="sampleTable">
                            <thead>
                                <tr>
                                    <th>User Name : </th>
                                    <th>User IP Address : </th>
                                    <th>User Login Country : </th>
                                    <th>User Device : </th>
                                    <th>User Broeser Name : </th>
                                    <th>User Oparating System :</th>
                                    <th>Last Login Time : </th>
                                </tr>
                                <tr>
                                    <th>
                                        <?php if($user_info->name): ?>
                                            <?php echo e($user_info->name); ?>

                                        <?php endif; ?>
                                    </th>
                                    <th>
                                        <?php if(!empty($loginfo->user_ip)): ?>
                                            <?php echo e($loginfo->user_ip); ?>

                                        <?php endif; ?>
                                    </th>
                                    <th>
                                        <?php if(!empty($loginfo->login_country)): ?>
                                            <?php echo e($loginfo->login_country); ?>

                                        <?php endif; ?>
                                    </th>
                                    <th>
                                        <?php if(!empty($loginfo->device)): ?>
                                            <?php echo e($loginfo->device); ?>

                                        <?php endif; ?>
                                    </th>
                                    <th>
                                        <?php if(!empty($loginfo->user_browser)): ?>
                                            <?php echo e($loginfo->user_browser); ?>

                                        <?php endif; ?>
                                    </th>
                                    <th>
                                        <?php if(!empty($loginfo->user_os)): ?>
                                            <?php echo e($loginfo->user_os); ?>

                                        <?php endif; ?>
                                    </th>
                                    <th>
                                        <?php if(!empty($loginfo->last_login_time)): ?>
                                            <?php echo e($loginfo->last_login_time); ?>

                                        <?php endif; ?>
                                    </th>
                                </tr>
                            </thead>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script></script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Desktop\llllllll\app (1)\resources\views/admin/stoff-profile/progile-log-info.blade.php ENDPATH**/ ?>