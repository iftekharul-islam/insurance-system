<?php $__env->startSection('title', 'Edit Loan Officer'); ?>

<?php $__env->startSection('content'); ?>


    <main class="app-content">
        <h3>Edit Loan Officer</h3>
        <hr />
        <div class="row">

            <div class="col-md-12">
                <div class="tile">
                    <!---Success Message--->

                    <!---Error Message--->


                    <div class="tile-body">
                        <form method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group col-md-12">
                                <label class="control-label">Name</label>
                                <input class="form-control" name="name" id="category" type="text" placeholder="Name"
                                    value="<?php echo e($data->name); ?>">
                                <?php if($errors->has('name')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12">
                                <label class="control-label">User Name</label>
                                <input class="form-control" name="email" id="category" type="text" placeholder="Email"
                                    value="<?php echo e($data->email); ?>">
                                <?php if($errors->has('email')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12">
                                <label class="control-label">Mobile No</label>
                                <input class="form-control" name="phone" type="text" placeholder="Mobile No"
                                    value="<?php echo e($data->phone); ?>">
                                <?php if($errors->has('phone')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('phone')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12">
                                <label class="control-label">Password</label>
                                <input class="form-control" name="password" id="category" type="password"
                                    placeholder="Enter Password">
                                <?php if($errors->has('password')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('password')); ?></div>
                                <?php endif; ?>
                            </div>

                            <input type="hidden" class="form-control" name="is_admin" value="3">

                            <div class="form-group col-md-4 align-self-end">

                                <button type="submit" class="btn btn-danger"
                                    style="background:#009688;border:none;">Update&nbsp;<i
                                        class="fa-solid fa-pen"></i></button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>

    </main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        function manager_role() {
            if ($("#managerRole").prop('checked') == false) {
                $('#branch').hide();
                //do something
            } else {
                $('#branch').show();
            }
        }
    </script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('manager.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Desktop\llllllll\NewLoan\resources\views/manager/loan-officer-edit.blade.php ENDPATH**/ ?>