
<?php $__env->startSection('title', 'Profile Settings'); ?>
<?php $__env->startSection('content'); ?>


    <main class="app-content">
        <h3>Profile Update</h3>
        <hr />
        <div class="row">

            <div class="col-md-12">
                <div class="tile">
                    <!---Success Message--->

                    <!---Error Message--->
                    <div class="tile-body">
                        <form method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php
                                $manager_id = Auth::user()->id;
                            ?>


                            <div class="form-group col-md-12">
                                <label class="control-label">Photo</label>
                                <input onchange="readPhoto(this);" class="form-control" name="photo" id="category"
                                    type="file" placeholder="Enter Password">
                                <?php if($errors->has('photo')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('photo')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12">
                                <label class="control-label">Name</label>

                                <input class="form-control"
                                    value="<?php if(!empty(ManagerProfile(Auth::user()->id)->name)): ?><?php echo e(ManagerProfile(Auth::user()->id)->name); ?><?php endif; ?>"
                                    name="name" id="category" type="text">
                                <?php if($errors->has('name')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12">
                                <label class="control-label">Email</label>
                                <input class="form-control" name="email" id="category" type="email"
                                    value="<?php if(!empty(ManagerProfile(Auth::user()->id)->email)): ?><?php echo e(ManagerProfile(Auth::user()->id)->email); ?><?php endif; ?>">
                                <?php if($errors->has('email')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12">
                                <label class="control-label">Mobile</label>
                                <input class="form-control" name="mobile" id="category" type="number"
                                    value="<?php if(!empty(ManagerProfile(Auth::user()->id)->mobile)): ?><?php echo e(ManagerProfile(Auth::user()->id)->mobile); ?><?php endif; ?>">
                                <?php if($errors->has('mobile')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('mobile')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12">
                                <label class="control-label">Address</label>
                                <input class="form-control" name="address" id="category" type="text"
                                    value="<?php if(!empty(ManagerProfile(Auth::user()->id)->address)): ?><?php echo e(ManagerProfile(Auth::user()->id)->address); ?><?php endif; ?>">
                                <?php if($errors->has('address')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('address')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-4 align-self-end">

                                <input type="submit" name="submit" id="submit" class="btn btn-primary"
                                    value=" Update Profile">
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>

    </main>

    <script type="text/javascript">
        function readPhoto(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    $('#img-src')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('loan_officer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Upwork\Loan\app\resources\views/manager/profile-settings.blade.php ENDPATH**/ ?>