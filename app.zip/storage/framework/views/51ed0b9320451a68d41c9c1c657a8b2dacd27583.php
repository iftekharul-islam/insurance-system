<?php $__env->startSection('title', 'Edit Notice'); ?>
<?php $__env->startSection('content'); ?>

    <main class="app-content">
        <h3>Notice Edit</h3>
        <hr />
        <div class="row">

            <div class="col-md-12">
                <div class="tile">
                    <!---Success Message--->

                    <!---Error Message--->


                    <div class="tile-body">
                        <form method="post" action="<?php echo e(route('notice.edit',$data->id)); ?>"  enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group col-md-12">
                                <label class="control-label">Add Notice</label>
                                <input class="form-control" name="notice" value="<?php echo e($data->notice); ?>" id="category"
                                    type="text" placeholder="Update Notice">
                                <?php if($errors->has('notice')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('notice')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-12">
                                <label class="control-label">Notice Description</label>
                                <textarea class="form-control" name="notice_dec" id="" cols="30" rows="5"><?php echo e($data->notice_dec); ?></textarea>
                                <?php if($errors->has('notice_dec')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('notice_dec')); ?></div>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-12">
                                <label class="control-label">Notice Validati</label>
                                <input class="form-control" name="notice_validati" id="category"
                                type="date" placeholder="Add Validati">
                                <?php if($errors->has('notice_validati')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('notice_validati')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-12">
                                <label class="control-label" style="font-weight:bold;">Notice Status:&nbsp;
                                    <sup style="color:red">*</sup>
                                </label>
                                <select class="form-control" name="noticestatus">
                                    <option value="<?php echo e($data->noticestatus); ?>"><?php echo e($data->noticestatus); ?></option>
                                    <option value="important">Important</option>
                                    <option value="new">New</option>
                                    <option value="hot">Hot</option>
                                </select>
                            </div>


                            <div class="form-group col-md-12">
                                <label class="control-label">Upload Pdf</label>
                                <input class="form-control" type="file" name="notice_pdf">
                                <?php if($errors->has('notice_pdf')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('notice_pdf')); ?></div>
                                <?php endif; ?>
                            </div>



                            <div class="form-group col-md-4 align-self-end">

                                <button class="btn" type="submit" style="background:#009688;color:#fff;">Update&nbsp;<i
                                        class="fa-solid fa-pencil"></i></button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>

    </main>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Desktop\llllllll\NewLoan\resources\views/admin/notice-edit.blade.php ENDPATH**/ ?>