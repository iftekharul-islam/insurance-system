<style type="text/css">

</style>
<header class="app-header">

    <a class="app-header__logo" href="#">Bfss-Ltd</a>


    <ul class="app-nav">

        <!-- Super Admin -->
        <?php if(Auth::user()->is_admin == 1): ?>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('admin.dashboard')); ?>">
                    <span class="app-menu__label">Dashboard</span>
                </a>
            </li>

            <li class="dropdown texr-center">
                <a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu">
                    Admin
                    <i class="fa-solid fa-caret-down"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-right">
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('list.admin')); ?>">
                            <i class="fa fa-cog fa-lg"></i>
                            List Admin

                        </a>
                    </li>

                </ul>
            </li>

            <li class="dropdown texr-center">
                <a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu">
                    Profile
                    <i class="fa-solid fa-caret-down"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-right">
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('all.manager.profile')); ?>">
                            Manager Profile
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('all.officer.profile')); ?>">
                            Loan Officer Profile
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('all.rejected.profile')); ?>">
                            Member Rejected Profile
                        </a>
                    </li>

                </ul>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('all.member.list')); ?>">
                    <span class="app-menu__label">Member List</span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('all.edit.request.member')); ?>">
                    <span class="app-menu__label">All Edit Request</span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('printManagerreport')); ?>">
                    <span class="app-menu__label">loan </span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('site.settings')); ?>">
                    <span class="app-menu__label">Settings</span>
                </a>
            </li>


            
            <li class="dropdown">
                <a href="<?php echo e(route('all.edit.request.member')); ?>" aria-label="Open Profile Menu"
                    style="line-height: 33px;" class="btn btn-primary" data-toggle="dropdown">
                    Notifications <span
                        class="badge bg-secondary"><?php echo e(count(SuperAdminNotification()) + count(Notification())); ?></span>
                </a>

                <ul class="dropdown-menu settings-menu dropdown-menu-right">

                    <?php $__currentLoopData = SuperAdminNotification(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="padding: 10px;display: flex;justify-content: space-between;">
                            <a>
                                <?php echo e($notification->n_type); ?>

                            </a>
                            <a href="<?php echo e(route('notification.view', $notification->id)); ?>">
                                View
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $__currentLoopData = Notification(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="padding: 10px;display: flex;justify-content: space-between;">
                            <a>
                                Edit Request
                            </a>
                            <a href="<?php echo e(route('member.edit.request.view', $item->id)); ?>">
                                View (<?php echo e(count(Notification())); ?>)
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </ul>
            </li>
            

        <?php endif; ?>
        <!-- Super Admin -->

        <!-- Notice Admin -->
        <?php if(Auth::user()->is_admin == 4): ?>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('home')); ?>">
                    <span class="app-menu__label">Dashboard</span>
                </a>
            </li>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('all.member.list')); ?>">
                    <span class="app-menu__label">Member List</span>
                </a>
            </li>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('notice.create')); ?>">
                    <span class="app-menu__label">Add Notice</span>
                </a>
            </li>

            
            <li class="dropdown">
                <a href="<?php echo e(route('all.edit.request.member')); ?>" aria-label="Open Profile Menu"
                    style="line-height: 33px;" class="btn btn-primary" data-toggle="dropdown">
                    Notifications <span class="badge bg-secondary"><?php echo e(count(NoticeAdminNotification())); ?></span>
                </a>

                <ul class="dropdown-menu settings-menu dropdown-menu-right">

                    <?php $__currentLoopData = NoticeAdminNotification(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="padding: 10px;display: flex;justify-content: space-between;">
                            <a>
                                <?php echo e($notification->n_type); ?>

                            </a>
                            <a href="<?php echo e(route('notification.view', $notification->id)); ?>">
                                View
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </li>
            

        <?php endif; ?>
        <!-- Notice Admin -->


        <!-- Manager -->
        <?php if(Auth::user()->is_admin == 2): ?>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('home')); ?>">
                    <span class="app-menu__label">Dashboard</span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('create.loan.officer')); ?>">
                    <span class="app-menu__label">Add Loan Officer</span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('loan.member.list')); ?>">
                    <span class="app-menu__label">Member List</span>
                </a>
            </li>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('manager.profile.settings')); ?>">
                    <span class="app-menu__label">Profile Settings</span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('manager.loanreport')); ?>">
                    <span class="app-menu__label">Loan Report</span>
                </a>
            </li>

            
            <li>
                <a class="app-nav__item" href="<?php echo e(route('all.show.request.accountsetup')); ?>" >
                    <span class="app-menu__label">Account setup</span>
                </a>
               

                
            </li>
            
        <?php endif; ?>
        <!-- Manager -->


        <!-- Loan Officer -->
        <?php if(Auth::user()->is_admin == 3): ?>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('home')); ?>">
                    <span class="app-menu__label">Dashboard</span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('user.form')); ?>">
                    <span class="app-menu__label">Form</span>
                </a>
            </li>


            <li>
                <a class="app-nav__item" href="<?php echo e(route('loan.oldform')); ?>">
                    <span class="app-menu__label">Old Form</span>
                </a>
            </li>


            <li>
                <a class="app-nav__item" href="<?php echo e(route('loacofficer.member.list')); ?>">
                    <span class="app-menu__label">Member List</span>
                </a>
            </li>

          
            <li>
                <a class="app-nav__item" href="<?php echo e(route('loan.amount.entry.form')); ?>">
                    <span class="app-menu__label">Recived Ammount</span>
                </a>
            </li>



            <li>
                <a class="app-nav__item" href="<?php echo e(route('officer.profile.settings')); ?>">
                    <span class="app-menu__label">Profile Settings</span>
                </a>
            </li>


            
            <li class="dropdown">
                <a href="<?php echo e(route('all.show.request.accountsetup')); ?>"
                    style="line-height: 33px;" class="btn btn-primary" data-toggle="dropdown">
                    Account Status 
                     
                </a>

                
            </li>
            


        <?php endif; ?>
        <!-- Loan Officer -->


        <li class="dropdown">
            <a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu">
                Welcome : <?php echo e(Auth::user()->name); ?>

                <i class="fa fa-user fa-lg"></i>
            </a>
            <ul class="dropdown-menu settings-menu dropdown-menu-right">
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault(); document.getElementById('frm-logout').submit();"><i
                            class="fa fa-user fa-lg"></i>Logout</a>
                </li>
                <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>


            </ul>
        </li>


    </ul>
</header>
<?php /**PATH C:\xampp\htdocs\Upwork\Loan\app\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>