<?php $__env->startSection('title', 'Officer Profile'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        @media  only screen and (max-width: 600px) {
            .tile {
                overflow-x: scroll;
            }
        }
    </style>

    <main class="app-content">

        <div class="row">
            <div class="col-md-12">
                <div class="tile" style="    border-top: 3px solid #009688;border-radius: 13px 13px 0px 0px;">
                    <div class="tile-body">
                        <table class="table table-hover table-bordered" id="sampleTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Branch Name</th>
                                    <th>Email</th>
                                    <th>Mobile No</th>
                                    <th>Address</th>

                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($data->id); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('uploads/profile/') . '/' . $data->photo); ?>"
                                            style="width: 121px;">
                                    </td>
                                    <td><?php echo e($data->name); ?></td>
                                    <td><?php echo e($data->manager_branch); ?></td>
                                    <td><?php echo e($data->email); ?></td>
                                    <td><?php echo e($data->mobile); ?></td>
                                    <td><?php echo e($data->address); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script></script>









<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Desktop\llllllll\NewLoan\resources\views/admin/profile/officer-profile.blade.php ENDPATH**/ ?>