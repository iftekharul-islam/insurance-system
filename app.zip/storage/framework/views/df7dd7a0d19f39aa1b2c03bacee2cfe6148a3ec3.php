<?php $__env->startSection('title', 'Officer Profile'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        @media  only screen and (max-width: 600px) {
            .tile {
                overflow-x: scroll;
            }
        }
    </style>

    <main class="app-content">

        <div class="row">
            <div class="col-md-12">
                <div class="tile" style="    border-top: 3px solid #009688;border-radius: 13px 13px 0px 0px;">
                    <div class="tile-body">
                        <table class="table table-hover table-bordered" id="sampleTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Image</th>
                                    <th>Email</th>
                                    <th>Loan Amount</th>
                                    <th>Manager Name</th>
                                    <th>Manager Branch Name</th>
                                    <th>Rejected Reason</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($data->id); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('public/loan_profile/') . '/' . $data->loan_owner_image); ?>"
                                                style="width: 121px;">
                                        </td>
                                        <td><?php echo e($data->name); ?></td>
                                        <td><?php echo e($data->loan_amount); ?></td>
                                        <td><?php echo e($data->manager_name); ?></td>
                                        <td><?php echo e($data->manager_branch); ?></td>
                                        <td><?php echo e($data->rejected_reason); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script></script>









<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/geekscua/bfss-ltd.com/resources/views/admin/profile/rejected-profile.blade.php ENDPATH**/ ?>