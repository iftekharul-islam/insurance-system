<style type="text/css">

</style>
<header class="app-header">

    <a class="app-header__logo" href="<?php echo e(route('home')); ?>">
        <img class="w-100" src="<?php echo e(asset('uploads/logo/') . '/' . settings()->site_logo); ?>" alt="">
    </a>

    <ul class="app-nav">

        <!-- Super Admin -->
        <?php if(Auth::user()->is_admin == 1): ?>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('home')); ?>">
                    <span class="app-menu__label">Dashboard</span>
                </a>
            </li>

            <li class="dropdown texr-center">
                <a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu">
                    Admin
                    <i class="fa-solid fa-caret-down"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-right">
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('list.admin')); ?>">
                            <i class="fa fa-cog fa-lg"></i>
                            List Admin
                        </a>
                    </li>

                </ul>
            </li>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('all.member.list')); ?>">
                    <span class="app-menu__label">Member List</span>
                </a>
            </li>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('all.close.request.member.list')); ?>">
                    <span class="app-menu__label">Close Request List</span>
                </a>
            </li>



            <li>
                <a class="app-nav__item" href="<?php echo e(route('managerreport.list')); ?>">
                    <span class="app-menu__label">Loan Report</span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('site.settings')); ?>">
                    <span class="app-menu__label">Settings</span>
                </a>
            </li>


            
            <li class="dropdown">
                <li>
                    <a class="app-nav__item" href="<?php echo e(route('loan.status')); ?>" >
                        <span class="app-menu__label">Account Status</span>
                    </a>
                </li>

            </li>
            

        <?php endif; ?>
        <!-- Super Admin -->

        <!-- Notice Admin -->
        <?php if(Auth::user()->is_admin == 4): ?>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('home')); ?>">
                    <span class="app-menu__label">Dashboard</span>
                </a>
            </li>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('all.member.list.notic')); ?>">
                    <span class="app-menu__label">Member List</span>
                </a>
            </li>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('notice.create')); ?>">
                    <span class="app-menu__label">Add Notice</span>
                </a>
            </li>

            
            <li class="dropdown">
                
                <li>
                    <a class="app-nav__item" href="<?php echo e(route('loan.status')); ?>" >
                        <span class="app-menu__label">Account Status</span>
                    </a>
                </li>
            </li>
            

        <?php endif; ?>
        <!-- Notice Admin -->


        <!-- Manager -->
        <?php if(Auth::user()->is_admin == 2): ?>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('home')); ?>">
                    <span class="app-menu__label">Dashboard</span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('create.loan.officer')); ?>">
                    <span class="app-menu__label">Add Loan Officer</span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('loanprofile.list.bymanager')); ?>">
                    <span class="app-menu__label">Member List</span>
                </a>
            </li>


            <li>
                <a class="app-nav__item" href="<?php echo e(route('loan.oldform')); ?>">
                    <span class="app-menu__label">Old From</span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('loan.setup')); ?>">
                    <span class="app-menu__label">Close Loan </span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('manager.profile.settings')); ?>">
                    <span class="app-menu__label">Profile Settings</span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('loanofficer.loanreport.bymanager')); ?>">
                    <span class="app-menu__label">Loan Report</span>
                </a>
            </li>


            <li>
                <a class="app-nav__item" href="<?php echo e(route('loan.status')); ?>" >
                    <span class="app-menu__label">Account Status</span>
                </a>
            </li>


        <?php endif; ?>
        <!-- Manager -->




        <!-- Loan Officer -->
        <?php if(Auth::user()->is_admin == 3): ?>
            <li>
                <a class="app-nav__item" href="<?php echo e(route('home')); ?>">
                    <span class="app-menu__label">Dashboard</span>
                </a>
            </li>

            <li>
                <a class="app-nav__item" href="<?php echo e(route('user.form')); ?>">
                    <span class="app-menu__label">Form</span>
                </a>
            </li>


            <li>
                <a class="app-nav__item" href="<?php echo e(route('loan.oldform')); ?>">
                    <span class="app-menu__label">Old Form</span>
                </a>
            </li>


            <li>
                <a class="app-nav__item" href="<?php echo e(route('loacofficer.member.list')); ?>">
                    <span class="app-menu__label">Member List</span>
                </a>
            </li>


            <li>
                <a class="app-nav__item" href="<?php echo e(route('loan.amount.entry.form')); ?>">
                    <span class="app-menu__label">Recived Ammount</span>
                </a>
            </li>



            <li>
                <a class="app-nav__item" href="<?php echo e(route('officer.profile.settings')); ?>">
                    <span class="app-menu__label">Profile Settings</span>
                </a>
            </li>


            
            <li class="dropdown">

                <li>
                    <a class="app-nav__item" href="<?php echo e(route('loan.status')); ?>" >
                        <span class="app-menu__label">Account Status</span>
                    </a>
                </li>

            </li>
            


        <?php endif; ?>
        <!-- Loan Officer -->


        <li class="dropdown">
            <a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu">
                Welcome : <?php echo e(Auth::user()->name); ?>

                <i class="fa fa-user fa-lg"></i>
            </a>
            <ul class="dropdown-menu settings-menu dropdown-menu-right">
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault(); document.getElementById('frm-logout').submit();"><i
                            class="fa fa-user fa-lg"></i>Logout</a>
                </li>
                <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>


            </ul>
        </li>


    </ul>
</header>
<?php /**PATH D:\Clients'Project\LoanProject\Version-2Copy\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>